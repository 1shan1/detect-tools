/************************************************************************************
module name:  PersonDetect.h
function: imput video stream, output objects with property

Vesion：V1.0  Copyright(C) 2016-2020 em-data, All rights reserved.
-------------------------------------------------------------------------------
modify record:
date                 version     author              state
2018/08/16           1.0	     YuanKui             create
**************************************************************************************/
#pragma once

#include "PersonTypes.h"
#include <opencv2/opencv.hpp>

class PedestrainTracker;

typedef struct tagPersonDetectInput
{
    int cameraID;       //由于每个实例会处理多路视频，这里以camereID号做区分
    cv::Mat img;        //视频流中一帧图像
}PersonDetectInput;

struct tag_Handler;
typedef struct tag_Handler* PDPtr;

/**
 * Get the current version
 * @return
 */
std::string getVersion();

/**
 * Create the Handler
 * @param ConfigRootPath : the config file root path
 * @param handler : the created handler
 * @return  0 success, other failed
 */
int emCreate(std::string ConfigRootPath, PDPtr* handler);

/**
 * Detect the current Person Count and the Person Direction
 * @param handler : the handler
 * @param image : the input Imaqe
 * @param result : the detect result
 * @return 0 success, other failed
 */
int emDetect(PDPtr handler,PersonDetectInput &pdInput, EMResult* result);

/**
 * Setting the Option
 * @param handler : the handler
 * @param option : the opti `on ptr need to set
 * @return 0 success, other failed
 */
int emSetOption(PDPtr handler, EMOption* option);

/**
 * Get the Option
 * @param handler : the handler
 * @param option : the option ptr need to get
 * @return 0 success, other failed
 */
int emGetOption(PDPtr handler, EMOption* option);

/**
 * Destory the created handler
 * @param handler : the handler
 * @return 0 success, other failed
 */
int emDestory(PDPtr handler);

