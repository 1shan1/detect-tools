#pragma once

#include <opencv2/opencv.hpp>
#include <string>
#include <iostream>

#define BEGIN_NAMESPACE namespace PD {
#define END_NAMESAPCE }

BEGIN_NAMESPACE

class BBOX
{
public:
    BBOX(){}
    BBOX(float x, float y, float w, float h){ m_x = x; m_y = y; m_width = w; m_height = h;}
    bool operator==(BBOX& rhs) const {
        if(m_x == rhs.m_x && m_y == rhs.m_y && m_width == rhs.m_width && m_height == rhs.m_height)
            return true;
        return false;
    }
    bool operator==(BBOX&& rhs) const {
        if(m_x == rhs.m_x && m_y == rhs.m_y && m_width == rhs.m_width && m_height == rhs.m_height)
            return true;
        return false;
    }
public:
    float m_x;
    float m_y;
    float m_width;
    float m_height;
};

END_NAMESAPCE

typedef struct {
    float x;
    float y;
    float w;
    float h;
    float score;
    int id;
    std::vector<cv::Vec3f> points;
} det_input;


