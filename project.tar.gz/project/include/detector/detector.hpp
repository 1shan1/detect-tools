#pragma once
#include "common.hpp"
#include "darknet.h"
#include <memory>
#include <caffe/caffe.hpp>

BEGIN_NAMESPACE

class Detector
{
public:
    Detector(std::string configPath){};
    virtual ~Detector() {}
    virtual int Detect(const cv::Mat& image, std::vector<BBOX>& persons) = 0;
    virtual int Detect(const cv::Mat& image,cv::Mat &dst, float & headCount) = 0;
};

class YoloDetector : public Detector
{
public:
    YoloDetector(std::string configPath);
    virtual ~YoloDetector(){}
    virtual int Detect(const cv::Mat& image, std::vector<BBOX>& persons);

private:
    std::vector<det_input> Detect(const cv::Mat& img);
    int max_idx(std::vector<float> &f);
    float IoU(det_input &det1, det_input &det2);
    void non_maxima_suppression(std::vector<det_input> &det, float fth);

private:
    float m_nms = 0.45;
    float m_thresh = 0.24;
    float m_hier_thresh = 0.5;
    std::string m_configFile;
    std::string m_weightFile;
    layer m_layer;
    std::shared_ptr<network> m_network;
};

class OpenPoseDetector : public Detector
{
public:
    OpenPoseDetector(std::string configPath);
    virtual ~OpenPoseDetector(){}
    virtual int Detect(const cv::Mat& image, std::vector<BBOX>& persons);
};

class CrowdDetector : public Detector
{
public:
    CrowdDetector(std::string configPath);
    virtual ~CrowdDetector(){};
    virtual void Detect(const cv::Mat src,cv::Mat &dst,float &headCount);

private:
    std::string netName_;
    std::string modelName_;
    caffe::shared_ptr<caffe::Net<float> > net_;

};

inline std:: shared_ptr<Detector> getCrowdDetector(std::string configPath)
{
    static std::shared_ptr<Detector> detector(new CrowdDetector(configPath));
    return detector;

}










inline std::shared_ptr<Detector> getYoloDetector(std::string configPath)
{
    static std::shared_ptr<Detector> detector(new YoloDetector(configPath));
    return detector;
}
END_NAMESAPCE