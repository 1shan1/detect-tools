#pragma once
#include "common.hpp"
#include "chrono"

BEGIN_NAMESPACE

using namespace std;
using namespace chrono;
class TimerUtils
{
public:
    void start() { m_start = system_clock::now(); }

    float cost_seconds() {
        m_end = system_clock::now();
        auto duration = duration_cast<seconds>(m_end - m_start);
        return duration.count();
    }

    float cost_milliseconds() {
        m_end = system_clock::now();
        auto duration = duration_cast<milliseconds>(m_end - m_start);
        return duration.count();
    }

    float cost_microseconds() {
        m_end = system_clock::now();
        auto duration = duration_cast<microseconds>(m_end - m_start);
        return duration.count();
    }

    float cost_nanoseconds() {
        m_end = system_clock::now();
        auto duration = duration_cast<nanoseconds>(m_end - m_start);
        return duration.count();
    }
private:
    system_clock::time_point m_start;
    system_clock::time_point m_end;
};

END_NAMESAPCE