#pragma once
#include "common.hpp"

BEGIN_NAMESPACE

float bboxIOU(BBOX box1, BBOX box2);

END_NAMESAPCE