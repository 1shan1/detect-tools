#pragma once
#include "common.hpp"
#include "tracker.hpp"
#include <memory>

BEGIN_NAMESPACE

class TrackerManager
{
public:
    TrackerManager();
    virtual ~TrackerManager(){}
    // update the tracking object every frame
    int update(const cv::Mat image);
    // merge the bboxes which detect by detector
    int updateBBox(const cv::Mat& image, std::vector<BBOX> bboxes);
    // get the current tracking bbox;
    int getBBox(std::vector<BBOX>& bboxes);

private:
    // kick every tracker every frame
    void heartHit();
    int mergeWithDetectorBBox(const cv::Mat& image, std::vector<BBOX>& detectBBoxes);
    int cleanTimeoutBBox();
    int addTracker(const cv::Mat& image, BBOX box);
    int removeTracker(std::shared_ptr<KCFTracker> trackerPtr);
    bool isContain(BBOX box);
    int getTheOverlapTrakcerIndex(BBOX);

    const float m_IOU_threshold = 0.8;
    std::vector<std::shared_ptr<KCFTracker>> m_trackerList;
};

inline std::shared_ptr<TrackerManager> getTrackerManager()
{
    static std::shared_ptr<TrackerManager> manager(new TrackerManager());
    return manager;
}
END_NAMESAPCE
