#pragma once

#include <opencv2/tracking/tracking.hpp>
#include "common.hpp"
#include <memory>

BEGIN_NAMESPACE

class Tracker
{
public:
    Tracker(){};
    virtual ~Tracker(){};
    virtual int init(const cv::Mat& image, BBOX box) = 0;
    virtual int update(const cv::Mat& image) = 0;
    virtual int update(const cv::Mat& image, BBOX& box) = 0;
    virtual BBOX getBBox() = 0;
};

class KCFTracker : public Tracker
{
public:
    KCFTracker();
    KCFTracker(BBOX box);
    virtual ~KCFTracker(){};
    virtual int init(const cv::Mat& image, BBOX box);
    virtual int reset(const cv::Mat& image, BBOX box);
    virtual int update(const cv::Mat& image);
    virtual int update(const cv::Mat& image, BBOX& box);
    virtual BBOX getBBox() { return m_roi; }

public:
    int m_hearthit;

private:
    void initialize();
    inline cv::Rect2d BBox2Rect2d(BBOX box) { return cv::Rect2d(box.m_x, box.m_y, box.m_width, box.m_height); };
    inline BBOX Rect2d2BBox(cv::Rect2d roi){ return BBOX(roi.x, roi.y, roi.width, roi.height); }
    BBOX m_roi;  // the current roi;
    cv::Ptr<cv::Tracker> m_kcfTracker;
    const int m_hearthit_threshold = 30;
};

inline std::shared_ptr<KCFTracker> getKCFTracker()
{
    std::shared_ptr<KCFTracker> tracker(new KCFTracker());
    return tracker;
}
END_NAMESAPCE