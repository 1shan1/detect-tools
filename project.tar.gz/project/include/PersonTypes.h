#pragma once
#include <opencv2/opencv.hpp>

typedef enum{
    CPU_MODE = 0,
    GPU_MODE = 1
}MODE;

typedef struct {
    MODE mode;
    int gpu_id;
}EMOption;

typedef struct{
    float x;
    float y;
    float height;
    float width;
}BBox;

typedef enum{
    MOVE_UP = 0,
    MOVE_DOWN = 1,
    MOVE_LEFT = 2,
    MOVE_RIGHT =3,
    STOP = 4,
    UNKNOWN = -1
}DIRECTION;

typedef struct{
    BBox bbox;
    int trackingStatus;     // 0 tracking, 1 lost, -1 new
    DIRECTION direction;
}LostInfo;

typedef struct {
    //std::vector<BBox> personList;
    std::vector<LostInfo> directionList;
}EMResult;