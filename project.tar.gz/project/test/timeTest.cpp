#include "utils/timer.hpp"
#include <chrono>
#include <thread>

using namespace PD;
int main()
{
    TimerUtils timer;
    std::cout<<"start test"<<std::endl;
    timer.start();
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
    std::cout<<"cost milliseconds: "<< timer.cost_milliseconds() <<std::endl;
    std::cout<<"cost seconds:" << timer.cost_seconds() <<std::endl;
    std::cout<<"cost nanoseconds: " <<timer.cost_nanoseconds() <<std::endl;
    std::cout<<"cost microseconds:" <<timer.cost_microseconds() <<std::endl;
}

