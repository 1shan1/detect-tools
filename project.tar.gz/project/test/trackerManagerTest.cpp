#include "track/tracker.hpp"
#include "detector/detector.hpp"
#include "track/trackerManager.hpp"
#include "utils/timer.hpp"
using namespace PD;

int main()
{
    std::string configPath ="../model";
    std::string videoFile = "../test_videos/20180827_184428.mp4";
    std::shared_ptr<Detector> detector = getYoloDetector(configPath);

    cv::VideoCapture capture(videoFile);
    cv::Mat image;
    std::shared_ptr<TrackerManager> tracker_manager = getTrackerManager();
    bool detect_flag = true;
    const int interval = 50;
    int count;
    TimerUtils timer;
    while(true)
    {
        capture >> image;
        std::vector<BBOX> bboxes;
        count++;

        if(count ==0 || count > interval)
            detect_flag = true;

        if(detect_flag) {
            std::cout<<"Detect now *******************"<<std::endl;
            detector->Detect(image, bboxes);
            detect_flag = false;
            count = 1;
            if(bboxes.size() > 0)
               tracker_manager->updateBBox(image,bboxes);
        }
        timer.start();
        tracker_manager->update(image);
        std::cout<<"tracking cost: "<<timer.cost_milliseconds()<<"ms"<<std::endl;
        tracker_manager->getBBox(bboxes);
        for(auto box : bboxes)
        {
            cv::rectangle(image, cv::Rect(box.m_x ,box.m_y, box.m_width, box.m_height), cv::Scalar(0, 0, 255), 3, 8, 0);
        }
        cv::imshow("test", image);
        cvWaitKey(50);
    }
}