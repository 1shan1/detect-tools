#include "track/tracker.hpp"
#include "detector/detector.hpp"

using namespace PD;

int main()
{
    std::string configPath ="../model";
    std::string videoFile = "../test_videos/20180827_184428.mp4";
    std::shared_ptr<Detector> detector = getYoloDetector(configPath);

    cv::VideoCapture capture(videoFile);
    cv::Mat image;
    KCFTracker tracker;
    bool detect_flag = true;
    const int interval = 100;
    int count;
    while(true)
    {
        capture >> image;
        std::vector<BBOX> bboxes;
        count++;
        BBOX test_box;

        if(count ==0 || count > interval)
            detect_flag = true;

        if(detect_flag) {
            std::cout<<"Detect now *******************"<<std::endl;
            detector->Detect(image, bboxes);
            detect_flag = false;
            count = 1;
            if(bboxes.size() > 0)
                tracker.init(image, bboxes[0]);
        }
        tracker.update(image);
        cv::rectangle(image, cv::Rect(tracker.getBBox().m_x ,tracker.getBBox().m_y, tracker.getBBox().m_width, tracker.getBBox().m_height), cv::Scalar(0, 0, 255), 3, 8, 0);
//        tracker.update(image, test_box);
//        cv::rectangle(image, cv::Rect(test_box.m_x ,test_box.m_y, test_box.m_width, test_box.m_height), cv::Scalar(0, 0, 255), 3, 8, 0);

//        for(auto box : bboxes)
//        {
//            cv::rectangle(image, cv::Rect(box.m_x ,box.m_y, box.m_width, box.m_height), cv::Scalar(0, 0, 255), 3, 8, 0);
//        }
        cv::imshow("test", image);
        cvWaitKey(50);
    }
}

