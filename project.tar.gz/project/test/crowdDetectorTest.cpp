#include <iostream>
#include "detector/detector.hpp"
#include <string>
using namespace caffe;
using namespace std;
using namespace PD;


int main()
{

    std::string configPath ="../model";
    std::string videoFile = "../test_videos/20180827_184428.mp4";
    string out_video = "/data_2/crowd-predict-video/video/out_video_1";
    std::shared_ptr<Detector> detector = getCrowdDetector(configPath);

    string mean_file = "";
    string img_path;
//    cv::Mat densitymap;
//    float headcount;
    cv::VideoCapture capture(videoFile);
    int num = 0;
    while(true)
    {
        cv::Mat dst;
        float headcount = 0 ;
        string outfile = out_video +"/"+std::to_string(num) + ".jpg";
        cv::Mat frame;
        capture >> frame;
        if (frame.empty()) break;
        cv::Mat new_img = frame.clone();
//        cv::Mat img=cv::imread(img_path);
//        if (img.data == NULL)
//        {
//            cout << endl << "read image error" << endl;
//            getchar();
//        }
        int64 t1 = cvGetTickCount();

        detector->Detect(new_img,dst,headcount);
        //CrowdEstimate::ins().process(new_img,densitymap,headcount);
        //process(img,densitymap,headcount);
        int64 t2 = cvGetTickCount();
        cv::putText(new_img,std::to_string(headcount), cv::Point(new_img.cols-400, 100), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(255, 23, 0), 5, 5);
        cout << "time cost:" << (t2-t1)/cvGetTickFrequency() / 1000000 << "s" << endl;
        cout << "per img people count:" << headcount <<endl;
        cv::imwrite(outfile,new_img);
        num++;

        //cvNamedWindow("new",CV_WINDOW_NORMAL);
        //cv::imshow("new", img);
        //cv::waitKey(10000);




    }
    return 0;



}

