#include <iostream>
#include "detector/detector.hpp"

using namespace PD;

int main()
{
    std::string configPath ="../model";
    std::string videoFile = "../test_videos/20180827_184428.mp4";
    std::shared_ptr<Detector> detector = getYoloDetector(configPath);

    cv::VideoCapture capture(videoFile);
    cv::Mat image;

    while(true)
    {
        capture >> image;
        std::vector<BBOX> bboxes;
        detector->Detect(image,bboxes);
        for(auto box : bboxes)
        {
            cv::rectangle(image, cv::Rect(box.m_x ,box.m_y, box.m_width, box.m_height), cv::Scalar(0, 0, 255), 3, 8, 0);
        }
        cv::imshow("test", image);
        cvWaitKey(10);
    }
}
