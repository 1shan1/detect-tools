#include <common.hpp>
#include "common.hpp"
#include "detector/detector.hpp"

BEGIN_NAMESPACE

YoloDetector::YoloDetector(std::string configRootPath): Detector(configRootPath)
{
    std::string cfg = configRootPath + "/" + "yolo/detectY_c";
    std::string weights = configRootPath + "/" + "yolo/detectY_w";
    m_configFile = cfg;
    m_weightFile = weights;
    m_network.reset(load_network(const_cast<char*>(m_configFile.c_str()), const_cast<char*>(m_weightFile.c_str()), 0));
    set_batch_network(m_network.get(), 1);
    m_layer = m_network->layers[m_network->n - 1];
}

int YoloDetector::Detect(const cv::Mat& image, std::vector<BBOX>& persons)
{
    std::vector<det_input> dets = Detect(image);
    for(auto item : dets)
    {
        BBOX box(item.x, item.y, item.w, item.h);
        persons.push_back(box);
    }
}

std::vector<det_input> YoloDetector::Detect(const cv::Mat& img)
{
    std::vector<det_input> det;
    srand(2222222);
    cv::Mat sample_single;
    cv::Mat m = img.clone();
    int im_w = img.cols;
    int im_h = img.rows;
    cv::resize(m, m, cv::Size(m_network->w, m_network->h));
    cv::cvtColor(m, m, cv::COLOR_BGR2RGB);
    m.convertTo(sample_single, CV_32FC3);        //转浮点型
    sample_single = sample_single / 255.0;

    size_t len = m_network->h * m_network->w * 3;
    float *X = new float[len];
    std::vector<cv::Mat> *input_channels = new std::vector<cv::Mat>;
    for (int i = 0; i < m.channels(); ++i)
    {
        float *XX = X + i * m_network->h * m_network->w;
        cv::Mat channel(m_network->h, m_network->w, CV_32FC1, XX);
        input_channels->push_back(channel);

    }
    cv::split(sample_single, *input_channels);

    network_predict(m_network.get(), X);
    int nboxes = 0;
    detection *dets = get_network_boxes(m_network.get(), m_network->w, m_network->h, m_thresh, m_hier_thresh, 0, 1, &nboxes);
    if (m_nms > 0) do_nms_sort(dets, nboxes, m_layer.classes, m_nms);
    delete[]X;
    for(int i = 0; i < nboxes; ++i)
    {
        for(int j = 0; j < m_layer.classes; ++j)
        {
            if(dets[i].prob[j] > 0.5)
            {
                det_input obj;
                box b = dets[i].bbox;
                int left  = (b.x-b.w/2.)*im_w;
                int right = (b.x+b.w/2.)*im_w;
                int top   = (b.y-b.h/2.)*im_h;
                int bot   = (b.y+b.h/2.)*im_h;

                if(left < 0) left = 0;
                if(right > im_w-1) right = im_w-1;
                if(top < 0) top = 0;
                if(bot > im_h-1) bot = im_h-1;

                obj.x = float(left);
                obj.y = float(top);
                obj.w = float(right - left);
                obj.h = float(bot - top);
                obj.id = j;
                obj.score = dets[i].prob[j];
                det.push_back(obj);
            }

        }
    }

    //std::sort(det.begin(), det.end(), [](const det_class &a, const det_class &b) { return a.score > b.score; });
    //non_maxima_suppression(det, _nms);
    delete input_channels;
    //delete dets;
    free_detections(dets, nboxes);
    return det;
}

int YoloDetector::max_idx(std::vector<float> &f)
{
    float max = f[0];
    int id = 0;
    for (int i = 1; i < f.size(); i++) {
        if (max < f[i]) {
            max = f[i];
            id = i;
        }
    }
    return id;
}

float YoloDetector::IoU(det_input &det1, det_input &det2)
{
    float area1 = det1.w * det1.h;
    float area2 = det2.w * det2.h;

    float over_w = std::max(0.f, (det1.w + det2.w) -
                                 (std::max(det1.x + det1.w, det2.x + det2.w) - std::min(det1.x, det2.x)));
    float over_h = std::max(0.f, (det1.h + det2.h) -
                                 (std::max(det1.y + det1.h, det2.y + det2.h) - std::min(det1.y, det2.y)));

    float over_area = over_w * over_h;
    return over_area / std::min(area1, area2);
}

void YoloDetector::non_maxima_suppression(std::vector<det_input> &det, float fth)
{
    for (int i = 0; i < det.size(); i++) {
        if (det[i].id == -1)
            continue;
        for (int j = i + 1; j < det.size(); j++) {
            if (det[i].id == det[j].id && IoU(det[i], det[j]) > fth)
                det[j].id = -1;
        }
    }
}
END_NAMESAPCE
