#include "utils/bboxUtils.hpp"

BEGIN_NAMESPACE

float bboxIOU(BBOX box1, BBOX box2)
{
    float area1 = box1.m_width * box1.m_height;
    float area2 = box2.m_width * box2.m_height;

    float over_w = std::max(0.f, (box1.m_width + box2.m_width) -
                                 (std::max(box1.m_x + box1.m_width, box2.m_x + box2.m_width) - std::min(box1.m_x, box2.m_x)));
    float over_h = std::max(0.f, (box1.m_height + box2.m_height) -
                                 (std::max(box1.m_y + box1.m_height, box2.m_y + box2.m_height) - std::min(box1.m_y, box2.m_y)));

    float over_area = over_w * over_h;
    return over_area / std::min(area1, area2);
}

END_NAMESAPCE

