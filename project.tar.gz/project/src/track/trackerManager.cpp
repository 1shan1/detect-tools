#include "track/trackerManager.hpp"
#include "utils/bboxUtils.hpp"

BEGIN_NAMESPACE

TrackerManager::TrackerManager()
{
}

int TrackerManager::update(const cv::Mat image)
{
    heartHit();
    for(auto tracker : m_trackerList)
    {
        int ret;
        ret = tracker->update(image);
        if(ret < 0){
            removeTracker(tracker);
        }
    }
    cleanTimeoutBBox();
}

int TrackerManager::updateBBox(const cv::Mat& image, std::vector<BBOX> bboxes)
{
    for(auto box : bboxes)
    {
        int ret;
        int index = getTheOverlapTrakcerIndex(box);
        if(index != -1 ){   // find a overlap box, we just update
            ret = m_trackerList[index]->init(image, box);
            if(ret == 0){
                std::cout<<"reinit the box success"<<std::endl;
            }
        }else{
            addTracker(image, box);
        }
    }
}

int TrackerManager::getBBox(std::vector<BBOX>& bboxes)
{
    bboxes.clear();
    for(auto tracker : m_trackerList)
    {
        bboxes.push_back(tracker->getBBox());
    }
}

void TrackerManager::heartHit()
{
    std::vector<std::shared_ptr<KCFTracker>> ::iterator it;
    for(it = m_trackerList.begin(); it != m_trackerList.end();it++)
    {
        (*it)->m_hearthit--;
    }
}

int TrackerManager::mergeWithDetectorBBox(const cv::Mat& image, std::vector<BBOX>& detectBBoxes)
{
    int ret;
    for(auto detectBox : detectBBoxes)
    {
        ret = getTheOverlapTrakcerIndex(detectBox);
        if(ret >= 0){ // find a overlap bbox
            m_trackerList[ret]->reset(image,detectBox);
        }else{ // not find a overlap bbox, it's a new box
            addTracker(image,detectBox);
        }
    }
}

int TrackerManager::cleanTimeoutBBox()
{
    std::vector<std::shared_ptr<KCFTracker>>::iterator it;
    for(it = m_trackerList.begin(); it != m_trackerList.end();)
    {
       if((*it)->m_hearthit < 0){
           std::cout <<"Find timeout BBox, and clear now"<<std::endl;
           it = m_trackerList.erase(it);
       }else{
           ++it;
       }
    }
}

int TrackerManager::addTracker(const cv::Mat& image, BBOX box)
{
    if(!isContain(box)){
        std::shared_ptr<KCFTracker> tracker = getKCFTracker();
        tracker->init(image, box);
        m_trackerList.push_back(tracker);
    }
    return 0;
}

int TrackerManager::removeTracker(std::shared_ptr<KCFTracker> trackerPtr)
{
    std::vector<std::shared_ptr<KCFTracker>>::iterator it;
    for(it = m_trackerList.begin(); it != m_trackerList.end();)
    {
        if((*it)->getBBox() == trackerPtr->getBBox()){
            std::cout<<"removeTracker called"<<std::endl;
            m_trackerList.erase(it);
        }
    }
}

bool TrackerManager::isContain(BBOX box)
{
    for(auto item : m_trackerList)
    {
        float score = bboxIOU(item->getBBox(), box);
        if(score > m_IOU_threshold)
            return true;
    }
    return false;
}

int TrackerManager::getTheOverlapTrakcerIndex(BBOX box)
{
    for(int i=0; i< m_trackerList.size();i++)
    {
        if(bboxIOU(box, m_trackerList[i]->getBBox()) > m_IOU_threshold){ // the box is overlap
            return i;
        }
    }
    return -1;  // not Found;
}

END_NAMESAPCE
