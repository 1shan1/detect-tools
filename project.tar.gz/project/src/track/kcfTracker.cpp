#include "common.hpp"
#include "track/tracker.hpp"

BEGIN_NAMESPACE

KCFTracker::KCFTracker() : Tracker()
{
    initialize();
}

KCFTracker::KCFTracker(BBOX box)
{
    initialize();
    m_roi = box;
}

int KCFTracker::init(const cv::Mat& image, BBOX box)
{
    bool ret;
    if(m_kcfTracker){
        m_roi = box;
        ret = m_kcfTracker->init(image, BBox2Rect2d(box));
        if(ret){
            return 0;
        }
    }
    return -1;
}

int KCFTracker::reset(const cv::Mat& image, BBOX box)
{
    bool ret;
    if(m_kcfTracker)
        m_kcfTracker.release();
    initialize();
    init(image, box);
}

int KCFTracker::update(const cv::Mat& image)
{
    return update(image, m_roi);
}

int KCFTracker::update(const cv::Mat& image, BBOX& box)
{
    bool ret;
    BBOX bbox;
    cv::Rect2d roi;
    if(m_kcfTracker){
        ret = m_kcfTracker->update(image, roi);
        if(ret) {
            bbox = Rect2d2BBox(roi);
            box = bbox;
            m_roi = bbox;
            return 0;
        }
    }
    return -1;
}

void KCFTracker::initialize()
{
    m_hearthit = m_hearthit_threshold;
    m_kcfTracker = cv::Tracker::create("KCF");
}

END_NAMESAPCE

