#ifndef ZHIHUI_ALG_VERSION_HPP
#define ZHIHUI_ALG_VERSION_HPP
#include <string>
const std::string VERSION_MAJOY("1");
const std::string VERSION_MINER("3");
const std::string VERSION_PATCH("1");
#endif
