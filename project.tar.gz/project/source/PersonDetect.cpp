#include "../include/PersonDetect.h"
#include "./person_analysis/person_analysis.h"
//#include "./person_tracker/person_tracker.h"
#include "version.h"


std::string getVersion()
{
    return ("Version:" + VERSION_MAJOY + "." + VERSION_MINER + "." + VERSION_PATCH);
}

int emCreate(std::string ConfigRootPath, PDPtr* handler)
{
    try
    {
        std::unique_ptr<PersonAnalysis> gai(new PersonAnalysis(ConfigRootPath));
        (*handler) = reinterpret_cast<PDPtr>(gai.release());
    }
    catch(std::exception& e)
    {
        return -1;
    }
    return 0;
}

int emDetect(PDPtr handler, PersonDetectInput &pdInput, EMResult* result)
{
    try
    {
        int ret;
        PersonAnalysis* gai = reinterpret_cast<PersonAnalysis*>(handler);
        if(gai == nullptr)
            return -1;
        ret = gai->Process(pdInput, result);
        return ret;
    }
    catch(std::exception& e)
    {
        return -1;
    }
}

int emSetOption(PDPtr handler, EMOption* option)
{
    try
    {
        int ret;
        PersonAnalysis* gai = reinterpret_cast<PersonAnalysis*>(handler);
//        if(gai == nullptr)
//            return -1;
        ret = gai->SetOption(option);
        return ret;
    }
    catch(std::exception& e)
    {
        return -1;
    }
//    return 0;
}

int emGetOption(PDPtr handler, EMOption* option)
{
    try
    {
        int ret;
        PersonAnalysis* gai = reinterpret_cast<PersonAnalysis*>(handler);
        if(gai == nullptr)
            return -1;
        ret = gai->GetOption(option);
        return ret;
    }
    catch(std::exception& e)
    {
        return -1;
    }
//    return 0;
}

int emDestory(PDPtr handler)
{
    try
    {
        PersonAnalysis* gai = reinterpret_cast<PersonAnalysis*>(handler);
        if(gai == nullptr)
            return -1;
        delete gai;
    }catch(std::exception& e){
        return -1;
    }
    return 0;
}

