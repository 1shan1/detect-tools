//
// Created by yuankui on 18-8-23.
//

#include "person_tracker.h"


PersonTrackers::PersonTrackers() {
//    p_multiTracker = new cv::MultiTracker(m_trackMode);
}

PersonTrackers::~PersonTrackers()
{

}

int PersonTrackers::Track(cv::Mat frame, std::vector<cv::Rect2d> &personRects, std::vector<CompareResult> &compareResults)
{
    std::vector<cv::Rect2d> trackRects;
    CompareResult   compare_result;

//    std::cout << "#######################trackTest##################" << std::endl;
//    std::cout << "personRects size::" << personRects.size() << std::endl;
//    std::cout << "#######################trackTest##################" << std::endl;
    if(personRects.empty())     // 当前帧没有人
    {
        m_firstFrame = true;
        if(!m_lastFramePersons.empty())
        {
            RectCompare(m_lastFramePersons, personRects, m_lastFramePersons, compareResults);
            m_lastFramePersons.clear();
        }
        return -1;
    }
    else                        // 当前帧有人
    {
        if(m_firstFrame)
        {
            m_firstFrame = false;
            m_lastFrame = frame;
            m_lastFramePersons = personRects;
            m_DirectionBuffer_Map = std::vector<std::vector<int>>(personRects.size(), std::vector<int>(m_bufferFrame, -1));//新人头数量初始化

            for(auto personRect:personRects)
            {
                compare_result.trackingStatus = -1;     // new
                compare_result.direction = -1;          // UNKNOWN
                compare_result.rectDraw = personRect;    // end rect
                compareResults.push_back(compare_result);
            }
//        p_multiTracker->add(m_lastFrame, personRects);
            return 0;
        }
        else
        {
            cv::MultiTracker *p_multiTracker = new cv::MultiTracker(m_trackMode);;
            p_multiTracker->add(m_lastFrame, m_lastFramePersons);
            p_multiTracker->update(frame);
            trackRects = p_multiTracker->objects;
            delete p_multiTracker;
//        {
//            std::cout << "#######################Track##################" << std::endl;
//            std::cout << "trackRects size::" << trackRects.size() << std::endl; //3
//            std::cout << "personRects size::" << personRects.size() << std::endl; //1
////            std::cout << "#i::" << i << std::endl;
////            std::cout << "tracking status::" << result->directionList[i].trackingStatus << std::endl;
////            std::cout << "Direction Value::" << result->directionList[i].direction << std::endl;
//            std::cout << "#######################Track##################" << std::endl;
//        }
            RectCompare(m_lastFramePersons, personRects, trackRects, compareResults);
            m_lastFrame = frame;                // 备份上一帧图片
            m_lastFramePersons = personRects;   // 备份上一帧图片中的人框
        }
    }


    return 0;
}

double PersonTrackers::IoU(cv::Rect2d &PersonRect, cv::Rect2d &TrackerRect) {
    double PersonArea = PersonRect.width * PersonRect.height;
    double TrackerArea = TrackerRect.width * TrackerRect.height;
    double over_w = std::max(0.0, (PersonRect.width + TrackerRect.width) - (std::max(PersonRect.x + PersonRect.width, TrackerRect.x + TrackerRect.width) - std::min(PersonRect.x, TrackerRect.x)));
    double over_h = std::max(0.0, (PersonRect.height + TrackerRect.height) - (std::max(PersonRect.y + PersonRect.height, TrackerRect.y + TrackerRect.height) - std::min(PersonRect.y, TrackerRect.y)));
    double over_area = over_w * over_h;
    return over_area / std::min(PersonArea, TrackerArea);
}

int PersonTrackers::directionJudge(cv::Rect lastRect, cv::Rect currentRect)
{
    int directionVal;
    int centralLast_x = lastRect.x + cvRound(lastRect.width / 2.0);
    int centralLast_y = lastRect.y + cvRound(lastRect.height / 2.0);
    int centralCurrent_x = currentRect.x + cvRound(currentRect.width / 2.0);
    int centralCurrent_y = currentRect.y + cvRound(currentRect.height / 2.0);
    int delta_x = centralCurrent_x - centralLast_x;
    int delta_y = centralCurrent_y - centralLast_y;
    double velocity = (1000 * sqrtf(delta_x * delta_x + delta_y * delta_y)) / currentRect.width;      // 归一化到当前距离的窗口
    double theta = abs(delta_y / (delta_x + 1e-6));

    if (theta > 1) {
        if (delta_y > 0) {
            directionVal = 1; // Move Down
        }
        else { directionVal = 0; }   // Move Up
    }
    else {
        if (delta_x > 0) {
            directionVal = 3;  //Move Right
        }
        else { directionVal = 2; }  //Move Left
    }

    if (velocity < m_stopVelocity_Threshold) directionVal = 4;
    return directionVal;
}

int PersonTrackers::lostDirectionJudge(std::vector<int> &PDBuffer)
{
//    {
//        std::vector<int> PersonDirections = *PDBuffer;
//        int centralStart_x = PersonInfo->startRect.x + cvRound(PersonInfo->startRect.width/2.0);
//        int centralStart_y = PersonInfo->startRect.y + cvRound(PersonInfo->startRect.height/2.0);
//        int centralEnd_x = PersonInfo->endRect.x + cvRound(PersonInfo->endRect.width/2.0);
//        int centralEnd_y = PersonInfo->endRect.y + cvRound(PersonInfo->endRect.height/2.0);
//        int delta_x = centralStart_x - centralEnd_x;
//        int delta_y = centralStart_y - centralEnd_y;
//        int ret = 0;
//
//        if(delta_x<100 && delta_y<100)
//        {
//            PersonInfo->trackingStatus = 0;
//        }
//    }

    int ret = 0;
    std::vector<int> directionCNT(4);
    for (auto PD : PDBuffer) {
        if (PD < 4 && PD >= 0 ) {
            directionCNT[PD]++;
        }
    }

    if (directionCNT[0] == directionCNT[1] && directionCNT[1] == directionCNT[2] &&
        directionCNT[2] == directionCNT[3]) {
        return ret;
    }
    else {
        auto maxIter = std::max_element(std::begin(directionCNT), std::end(directionCNT));
        ret = int(std::distance(std::begin(directionCNT), maxIter));
        return ret;
    }
}

int PersonTrackers::RectCompare(std::vector<cv::Rect2d> &m_lastFramePersons, std::vector<cv::Rect2d> &personRects, std::vector<cv::Rect2d> &trackRects, std::vector<CompareResult> &compareResults)
{
    if (trackRects.empty()) {
        return -1;
    }

    CompareResult compare_result;

    for (int i = 0; i < personRects.size(); i++)
    {
        bool isFoud = false;
        for (int j = 0; j < trackRects.size(); j++)
        {
            double IoU_val = IoU(personRects[j], trackRects[i]);
            if (IoU_val > IoU_Threshold)    // 当前检测行人中找到跟踪行人
            {
                isFoud = true;
                break;
            }
        }
        if (!isFoud)     // new
        {
            compare_result.trackingStatus = -1;     // new
            compare_result.direction = -1;          // UNKNOWN
            compare_result.rectDraw = personRects[i];    // end rect
            compareResults.push_back(compare_result);
            m_DirectionBuffer_Map.emplace_back(std::vector<int>(m_bufferFrame, -1));   // 将新人加入队尾
        }
    }

    for (int i = 0; i < trackRects.size(); i++)
    {
        bool isFoud = false;
        for (int j = 0; j < personRects.size(); j++)
        {
            double IoU_val = IoU(personRects[j], trackRects[i]);
            if (IoU_val > IoU_Threshold)    // 当前检测行人中找到跟踪行人
            {
                isFoud = true;
                compare_result.trackingStatus = 0;  // tracking
                compare_result.direction = directionJudge(m_lastFramePersons[i], personRects[j]);

                m_DirectionBuffer_Map[i].erase(m_DirectionBuffer_Map[i].begin());
                m_DirectionBuffer_Map[i].push_back(compare_result.direction);       // 对第i个老人进行修改

                compare_result.rectDraw = personRects[j];
                compareResults.push_back(compare_result);
                break;
            }
        }
        if (!isFoud)     // lost
        {
            compare_result.trackingStatus = 1;  // lost
            compare_result.direction = lostDirectionJudge(m_DirectionBuffer_Map[i]);
            compare_result.rectDraw = trackRects[i];    // end rect
            compareResults.push_back(compare_result);   // 压入丢失行人信息
            m_DirectionBuffer_Map.erase(m_DirectionBuffer_Map.begin() + i);         // 擦除结构中丢失的行人
        }
    }
    return 0;
}

