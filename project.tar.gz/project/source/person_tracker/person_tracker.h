//
// Created by yuankui on 18-8-23.
//

#pragma once

#include "../../include/PersonDetect.h"
#include <opencv2/tracking/tracking.hpp>

typedef struct {
    int trackingStatus;     // 0:tracking 1:lost -1:new
    int direction;          // 0:up 1:down 2:left 3:right 4:stop  when trackingStatus:0 or 1
    cv::Rect2d  rectDraw;   // trackingStatus:0 -1 or 1(endRect)
} CompareResult;

//typedef std::map<int, cv::MultiTracker*> PersonTracker_Map;

class PersonTrackers {
public:
    PersonTrackers();
    virtual ~PersonTrackers();
    int Track(cv::Mat frame, std::vector<cv::Rect2d> &personRects, std::vector<CompareResult> &compareResults);

private:
    double IoU(cv::Rect2d &PersonRect, cv::Rect2d &TrackerRect);
    int directionJudge(cv::Rect lastRect, cv::Rect currentRect);
    int lostDirectionJudge(std::vector<int> &PDBuffer);
    int RectCompare(std::vector<cv::Rect2d> &m_lastFramePersons, std::vector<cv::Rect2d> &personRects, std::vector<cv::Rect2d> &trackRects, std::vector<CompareResult> &compareResults);

private:
    bool m_firstFrame = true;
    std::string m_trackMode = "KCF";
    double IoU_Threshold = 0.4;
    double m_stopVelocity_Threshold = 100;
    int m_bufferFrame = 10;

    cv::Mat m_lastFrame;
    std::vector<cv::Rect2d> m_lastFramePersons;
//    cv::MultiTracker *p_multiTracker;
    std::vector<std::vector<int>>  m_DirectionBuffer_Map;
};

static std::map<int, PersonTrackers*> createPersonTrackers()
{
    PersonTrackers *pTracker = new PersonTrackers();
    std::map<int, PersonTrackers*> PersonTrackers_Map;
    PersonTrackers_Map.insert(std::pair<int, PersonTrackers*>(0, pTracker));
    return PersonTrackers_Map;
}