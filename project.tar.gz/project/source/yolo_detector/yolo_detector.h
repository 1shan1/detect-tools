/************************************************************************************
module name:  yolo_detector.h
function: interfaces of darknet's yolov3 decorated for c++ to call

Vesion：V1.0  Copyright(C) 2016-2020 em-data, All rights reserved.
-------------------------------------------------------------------------------
modify record:
date                 version     author              state
2018/08/06           1.0	     YuanKui             create
**************************************************************************************/
#pragma once

#include "common.hpp"
#include <darknet.h>

class YoloDetector{
public:
    YoloDetector(std::string configRootPath);
    virtual ~YoloDetector();
    std::vector<det_input> Detect(const cv::Mat& img);

private:
//    void process(std::vector<det_class> det,std::vector< std::pair<cv::Rect,det_class> > &out);
    int max_idx(std::vector<float> &f);
    float IoU(det_input &det1, det_input &det2);
    void non_maxima_suppression(std::vector<det_input> &det, float fth);

private:
    float _nms = 0.45;
    float _thresh = 0.24;
    float _hier_thresh = 0.5;
    char *_cfgfile;
    char *_weightfile;
    layer _l;
    network* _net;
};

static std::unique_ptr<YoloDetector> createYoloDetector(std::string configRootPath)
{
    return std::unique_ptr<YoloDetector>(new YoloDetector(configRootPath));
}