/************************************************************************************
module name:  person_analysis.hpp

Vesion：V1.0  Copyright(C) 2016-2020 em-data, All rights reserved.
-------------------------------------------------------------------------------
modify record:
date                 version     author              state
2018/08/13           1.0	     YuanKui             create
**************************************************************************************/
#pragma once

#include "../yolo_detector/yolo_detector.h"
#include "../person_tracker/person_tracker.h"
#include "PersonTypes.h"


class PersonAnalysis{
public:
    PersonAnalysis(std::string configRootPath);
    virtual ~PersonAnalysis();
    int Process(PersonDetectInput &pdInput, EMResult* result);
    int SetOption(EMOption* option);
    int GetOption(EMOption* option);

private:
    void ToEMResult(std::vector<CompareResult> &compareResults, EMResult* result);
    void ToEMResult(std::vector<cv::Rect2d>  &detectRects, EMResult* result);

private:
    std::unique_ptr<YoloDetector> m_yoloDetector;
    std::map<int, PersonTrackers*> m_PersonTracker_Map;
};