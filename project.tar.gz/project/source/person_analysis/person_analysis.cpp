#include "caffe/caffe.hpp"
#include "person_analysis.h"

using namespace caffe;

PersonAnalysis::PersonAnalysis(std::string configRootPath)
{
    m_yoloDetector = createYoloDetector(configRootPath);
    m_PersonTracker_Map = createPersonTrackers();
}

PersonAnalysis::~PersonAnalysis()
{

}

int PersonAnalysis::Process(PersonDetectInput &pdInput, EMResult* result)
{
    std::vector<det_input> yolo_objects;
    std::vector<cv::Rect2d> detectRects;
    std::vector<CompareResult> compareResults;     // i for each person

    yolo_objects = m_yoloDetector->Detect(pdInput.img);
    for(int i = 0; i < yolo_objects.size(); i++)
    {
        if (yolo_objects[i].id == -1) {
            continue;
        }
        else if ((yolo_objects[i].id == 0) && (yolo_objects[i].w > 15) && (yolo_objects[i].h > 15))// && (yolo_objects[i].h/yolo_objects[i].w > 1.3))
        {
            detectRects.push_back(cv::Rect2d(yolo_objects[i].x, yolo_objects[i].y, yolo_objects[i].w, yolo_objects[i].h));
        }
    }

//    if(m_PersonTracker_Map.find(pdInput.cameraID) == m_PersonTracker_Map.end())
//    {
//        PersonTrackers *pTracker = new PersonTrackers();
//        m_PersonTracker_Map.insert(std::pair<int, PersonTrackers*>(pdInput.cameraID, pTracker));
//    }
//    m_PersonTracker_Map[pdInput.cameraID]->Track(pdInput.img, detectRects, compareResults);
//    ToEMResult(compareResults, result);

    ToEMResult(detectRects, result);
    return 0;
}

int PersonAnalysis::SetOption(EMOption *option)
{
    if(option->mode == GPU_MODE){
#undef GPU
        Caffe::set_mode(Caffe::GPU);
#define GPU
        Caffe::SetDevice(option->gpu_id);   // set Caffe
        cuda_set_device(option->gpu_id);    // set Darknet

    }else if(option->mode == CPU_MODE){
#undef GPU
        Caffe::set_mode(Caffe::GPU);
#define GPU
        std::cout << "Error::Darknet CPU mode set failed!" << std::endl;
    }else{
        return -1;
    }
    return 0;
}

int PersonAnalysis::GetOption(EMOption *option)
{
    return 0;
}

void PersonAnalysis::ToEMResult(std::vector<CompareResult> &compareResults, EMResult* result)
{
    LostInfo trackLostInfo;

    for(int i=0; i<compareResults.size(); i++)
    {
        trackLostInfo.trackingStatus = compareResults[i].trackingStatus;
        trackLostInfo.direction = DIRECTION(compareResults[i].direction);
        trackLostInfo.bbox.x = float(compareResults[i].rectDraw.x);
        trackLostInfo.bbox.y = float(compareResults[i].rectDraw.y);
        trackLostInfo.bbox.width = float(compareResults[i].rectDraw.width);
        trackLostInfo.bbox.height = float(compareResults[i].rectDraw.height);
        result->directionList.push_back(trackLostInfo);

//        {
//            std::cout << "#######################ToEMResult##################" << std::endl;
//            std::cout << "#i::" << i << std::endl;
//            std::cout << "tracking status::" << result->directionList[i].trackingStatus << std::endl;
//            std::cout << "Direction Value::" << result->directionList[i].direction << std::endl;
//            std::cout << "#######################ToEMResult##################" << std::endl;
//        }
    }


}

void PersonAnalysis::ToEMResult(std::vector<cv::Rect2d>  &detectRects, EMResult* result)
{
    LostInfo trackLostInfo;

    for(int i=0; i<detectRects.size(); i++)
    {
        trackLostInfo.bbox.x = float(detectRects[i].x);
        trackLostInfo.bbox.y = float(detectRects[i].y);
        trackLostInfo.bbox.width = float(detectRects[i].width);
        trackLostInfo.bbox.height = float(detectRects[i].height);
        result->directionList.push_back(trackLostInfo);

//        {
//            std::cout << "#######################ToEMResult##################" << std::endl;
//            std::cout << "#i::" << i << std::endl;
//            std::cout << "tracking status::" << result->directionList[i].trackingStatus << std::endl;
//            std::cout << "Direction Value::" << result->directionList[i].direction << std::endl;
//            std::cout << "#######################ToEMResult##################" << std::endl;
//        }
    }


}
