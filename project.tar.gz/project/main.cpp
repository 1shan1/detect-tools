#include "include/PersonTypes.h"
#include "include/PersonDetect.h"
#include "include/common.hpp"
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>

//#include <opencv2/core/utility.hpp>
#include <opencv2/tracking/tracking.hpp>
//#include <opencv2/tracking.hpp>
//#include <opencv2/videoio.hpp>
//#include <opencv2/highgui.hpp>

#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
using namespace cv;

namespace fs = boost::filesystem;

inline int get_filenames(const std::string& dir, std::vector<std::string>& filenames)
{
    fs::path path(dir);
    if (!fs::exists(path))
    {
        return -1;
    }

    fs::directory_iterator end_iter;
    for (fs::directory_iterator iter(path); iter!=end_iter; ++iter)
    {
        if (fs::is_regular_file(iter->status()))
        {
            filenames.push_back(iter->path().string());
        }

        if (fs::is_directory(iter->status()))
        {
            get_filenames(iter->path().string(), filenames);
        }
    }
    return filenames.size();
}

inline std::string direction_num2string(DIRECTION direction_num)
{
    std::string direction;

    switch(direction_num)
    {
        case 0:
            direction = "Up";
            break;
        case 1:
            direction = "Down";
            break;
        case 2:
            direction = "Left";
            break;
        case 3:
            direction = "Right";
            break;
        case 4:
            direction = "Stop";
            break;
        default:
            direction = "New";
        break;
    }
    return direction;
}

//void YoloFolderTest(std::string imagePath)
//{
////    EMResult result;
//    PDPtr handle;
//    PersonDetectInput pdInput;
//    EMOption option;
//    option.mode = GPU_MODE;
//    option.gpu_id = 0;
//    int count = 0;
//    int totalPeopleCnt = 0;
//
//    std::vector<std::pair<cv::Rect, det_input> > out;
//    out.clear();
//
//    std::string cfgPath = "/data/Pedestrian detection/project/PersonDetect/models";
//    std::string dstPath = "/data/Pedestrian detection/project/PersonDetect/res";
//
//    emCreate(cfgPath, &handle);
//    emSetOption(handle, &option);
//
//    std::vector<std::string> fileList;
//    count = get_filenames(imagePath, fileList);
//    cv::Mat new_img2;
//    if(count >0)
//    {
//        for(auto fileItem : fileList)
//        {
//            int peopleCntPerImg = 0;
////            std::cout<<fileItem<<std::endl;
//            cv::Mat img = cv::imread(fileItem);
//            pdInput.img = img.clone();
//            EMResult result;
//            boost::posix_time::ptime time_now,time_now1;
//            boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse;
//            time_now=boost::posix_time::microsec_clock::universal_time();
//
//            emDetect(handle, pdInput, &result);
//
//            time_now1= boost::posix_time::microsec_clock::universal_time();
//            time_elapse = time_now1 - time_now;
//            std::cout << "t1 time per frame: " << time_elapse.total_milliseconds() << std::endl;
//
//            int npos = fileItem.find_last_of('.');
//            std::string out_fileName = fileItem.substr(0, npos);
//            int mpos = fileItem.find_last_of('/');
//            out_fileName = out_fileName.substr(mpos + 1);
//            std::string outFile = dstPath + "/" + out_fileName + ".jpg";
//
//            if(result.personList.size() > 0)
//            {
////                std::cout << "Person List num::" << result.personList.size() << std::endl;
////                std::cout << "Direction List num::" << result.directionList.size() << std::endl;
//
//                for(int i=0; i<result.personList.size(); i++)
//                {
//                    BBox pLoc = result.personList[i];
//
//                    peopleCntPerImg +=1;
//                    totalPeopleCnt += 1;
////                    std::cout<<pLoc.x<<" "<<pLoc.y<<" "<<pLoc.width<<" "<<pLoc.height<<std::endl;
//                    cv::rectangle(pdInput.img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
////                    cv::putText(pdInput.img, "p", cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 23, 0), 5, 5);
//                    if(result.directionList[i].direction == 4)
//                    {
//                        cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(200, 200, 200), 5, 5);
//                    }
//                    else
//                    {
//                        cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(0, 0, 255), 5, 5);
//                    }
//                }
//                std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
//                cv::imwrite(outFile, pdInput.img);
//                cvNamedWindow("new",CV_WINDOW_NORMAL);
//                cv::imshow("new", pdInput.img);
//                if (new_img2.data)
//                {
//                    cvNamedWindow("old",CV_WINDOW_NORMAL);
//                    cv::imshow("old", new_img2);
//                }
//                new_img2 = pdInput.img.clone();
//                cv::waitKey(0);
//            }
//            else
//            {
//                cv::imwrite(outFile, pdInput.img);
//            }
//
//            //std::cout << "per frame people count: " <<every_img_num<< std::endl;
//            printf("File total: %d.\n", count);
//            printf("Total number of people: %d.\n", totalPeopleCnt);
//        }
//    }
//}

void trackTest(std::string lisdir)
{
    PDPtr handle;
    PersonDetectInput pdInput;
    pdInput.cameraID = 0;
    EMOption option;
    option.mode = GPU_MODE;
    option.gpu_id = 0;
    int count = 0;
    int totalPeopleCnt = 0;

    std::vector<std::pair<cv::Rect, det_input> > out;
    out.clear();

    std::string cfgPath = "/data/Pedestrian detection/project/PersonDetect/models";
    std::string dstPath = "/data/Pedestrian detection/data/res";

    emCreate(cfgPath, &handle);
    emSetOption(handle, &option);

    std::ifstream fin(lisdir);
    std::vector<std::string> fileList;
    std::string file;
    while (getline(fin, file))
    {
        count++;
//        std::cout << "Current file::" << file << std::endl;
        fileList.push_back(file);
    }

    cv::Mat new_img2;
    if(count >0)
    {
        for(auto fileItem : fileList)
        {
            int peopleCntPerImg = 0;
            std::cout<<fileItem<<std::endl;
            cv::Mat img = cv::imread(fileItem);
            pdInput.img = img.clone();
            EMResult result;
            boost::posix_time::ptime time_now,time_now1;
            boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse;
            time_now=boost::posix_time::microsec_clock::universal_time();
            emDetect(handle, pdInput, &result);
            time_now1= boost::posix_time::microsec_clock::universal_time();
            time_elapse = time_now1 - time_now;
            std::cout << "t1 time per frame: " << time_elapse.total_milliseconds() << std::endl;

            int npos = fileItem.find_last_of('.');
            std::string out_fileName = fileItem.substr(0, npos);
            int mpos = fileItem.find_last_of('/');
            out_fileName = out_fileName.substr(mpos + 1);
            std::string outFile = dstPath + "/" + out_fileName + ".jpg";

            if(result.directionList.size() > 0)
            {
//                std::cout << "Person List num::" << result.directionList.size() << std::endl;
//                std::cout << "Direction List num::" << result.directionList.size() << std::endl;

                for(int i=0; i<result.directionList.size(); i++)
                {

                    BBox pLoc = result.directionList[i].bbox;
                    peopleCntPerImg +=1;
                    totalPeopleCnt += 1;

                    if(result.directionList[i].trackingStatus == 1)
                    {
                        std::cout << "#######################trackTest##################" << std::endl;
                        std::cout << "#i::" << i << std::endl;
                        std::cout << "Tracking Status::" << result.directionList[i].trackingStatus << std::endl;
                        std::cout << "Rect X::" << pLoc.x << std::endl;
                        std::cout << "Rect Y::" << pLoc.y << std::endl;
                        std::cout << "Direction Value::" << result.directionList[i].direction << std::endl;
                        std::cout << "Print Direction::" << direction_num2string(result.directionList[i].direction) << std::endl;
                        std::cout << "#######################trackTest##################" << std::endl;
                    }
                    else
                    {
                        cv::rectangle(pdInput.img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
                        if(result.directionList[i].direction == 4)
                        {
                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(200, 200, 200), 5, 5);
                        }
                        else
                        {
                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(0, 0, 255), 5, 5);
                        }
                    }
                }
                std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
            }

            cv::imwrite(outFile, pdInput.img);
            {
                cvNamedWindow("new",CV_WINDOW_NORMAL);
                cv::imshow("new", pdInput.img);
                if (new_img2.data)
                {
                    cvNamedWindow("old",CV_WINDOW_NORMAL);
                    cv::imshow("old", new_img2);
                }
                new_img2 = pdInput.img.clone();
                cv::waitKey(0);
            }

            //std::cout << "per frame people count: " <<every_img_num<< std::endl;
            printf("File total: %d.\n", count);
            printf("Total number of people: %d.\n", totalPeopleCnt);
        }
    }
}

void VideoTrack(std::string videoFile)
{
    PDPtr handle;
    PersonDetectInput pdInput;
    pdInput.cameraID = 0;
    EMOption option;
    option.mode = GPU_MODE;
    option.gpu_id = 0;
//    int count = 0;
    int totalPeopleCnt = 0;

    std::vector<std::pair<cv::Rect, det_input> > out;
    out.clear();

    std::string cfgPath = "../model/yolo";
    emCreate(cfgPath, &handle);
    emSetOption(handle, &option);

    cv::VideoCapture capture(videoFile);
    if (!capture.isOpened())
    {
        std::cout << "Error::Read video Failed!" << std::endl;
        return;
    }
    cv::Mat frame;
    cv::namedWindow("Janshe Video", CV_WINDOW_KEEPRATIO);
    float fps = 0;
    int frameCnt = 0;
    {
        while (1)
        {
            frameCnt++;
            boost::posix_time::ptime time_start,time_1, time_2;
            boost::posix_time::millisec_posix_time_system_config::time_duration_type detect_time, frame_time;
            time_start=boost::posix_time::microsec_clock::universal_time();
            int peopleCntPerImg = 0;
            capture >> frame;
            if(frameCnt%10 != 0) continue;
            pdInput.img = frame.clone();
            EMResult result;
            emDetect(handle, pdInput, &result);
            time_1= boost::posix_time::microsec_clock::universal_time();
            detect_time = time_1 - time_start;
            std::cout << "t1 time per frame: " << detect_time.total_milliseconds() << std::endl;
            if(result.directionList.size() > 0)
            {
                for(int i=0; i<result.directionList.size(); i++)
                {
                    BBox pLoc = result.directionList[i].bbox;
                    peopleCntPerImg +=1;
                    totalPeopleCnt += 1;
//                    if(result.directionList[i].trackingStatus == 1)
//                    {
//                        std::cout << "#######################trackTest##################" << std::endl;
//                        std::cout << "#i::" << i << std::endl;
//                        std::cout << "Tracking Status::" << result.directionList[i].trackingStatus << std::endl;
//                        std::cout << "Rect X::" << pLoc.x << std::endl;
//                        std::cout << "Rect Y::" << pLoc.y << std::endl;
//                        std::cout << "Direction Value::" << result.directionList[i].direction << std::endl;
//                        std::cout << "Print Direction::" << direction_num2string(result.directionList[i].direction) << std::endl;
//                        std::cout << "#######################trackTest##################" << std::endl;
//                    }
//                    else
                    {
                        cv::rectangle(pdInput.img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
//                        if(result.directionList[i].direction == 4)
//                        {
//                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(200, 200, 200), 5, 5);
//                        }
//                        else
//                        {
//                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(0, 0, 255), 5, 5);
//                        }
                    }

                }
                std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
            }
            time_2= boost::posix_time::microsec_clock::universal_time();
            frame_time = time_2 - time_start;
            fps = 1000.0/frame_time.total_milliseconds();
            cv::putText(pdInput.img, "fps:" + std::to_string(fps), cv::Point(pdInput.img.cols-400, 100), cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(200, 200, 200), 2, 2);
            imshow("Janshe Video", pdInput.img);
            if (cv::waitKey(1) == 'q')
            {
                break;
            }
        }
    }
    cv::destroyWindow("Janshe Video");
    capture.release();
}

void VideoTrackC(const char *videoFile)
{
    PDPtr handle = NULL;
    PersonDetectInput pdInput;
    pdInput.cameraID = 0;
    EMOption option;
    option.mode = GPU_MODE;
    option.gpu_id = 0;
//    int count = 0;
    int totalPeopleCnt = 0;

    std::vector<std::pair<cv::Rect, det_input> > out;
    out.clear();

    std::string cfgPath = "/data/Pedestrian detection/project/PersonDetect/models";

    emSetOption(handle, &option);
    emCreate(cfgPath, &handle);

    CvCapture* capture = cvCreateFileCapture(videoFile);
    if(!cvGrabFrame(capture))
    {
        std::cout << "Error::Read video Failed!" << std::endl;
        return;
    }
    IplImage* frame;
    cvNamedWindow("Janshe Video", CV_WINDOW_KEEPRATIO);
    float fps = 0;
    int frameCnt = 0;
//    double rate= capture.get(CV_CAP_PROP_FPS);      // 读取图像帧率
//    double frame_num = cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);  // 获取图像总帧数

//    std::cout << "frame number:: " << frame_num << std::endl;

//    if(frame_num >0)
    {
        while (1)
        {
            frameCnt++;
            boost::posix_time::ptime time_start,time_1, time_2;
            boost::posix_time::millisec_posix_time_system_config::time_duration_type detect_time, frame_time;
            time_start=boost::posix_time::microsec_clock::universal_time();

            int peopleCntPerImg = 0;
            frame = cvQueryFrame(capture);
            if(frameCnt%25 != 0) continue;
            pdInput.img = cv::cvarrToMat(frame);
            EMResult result;
            emDetect(handle, pdInput, &result);
            time_1= boost::posix_time::microsec_clock::universal_time();
            detect_time = time_1 - time_start;
            std::cout << "t1 time per frame: " << detect_time.total_milliseconds() << std::endl;
            if(result.directionList.size() > 0)
            {
                for(int i=0; i<result.directionList.size(); i++)
                {
                    BBox pLoc = result.directionList[i].bbox;
                    peopleCntPerImg +=1;
                    totalPeopleCnt += 1;

                    if(result.directionList[i].trackingStatus == 1)
                    {
                        std::cout << "#######################trackTest##################" << std::endl;
                        std::cout << "#i::" << i << std::endl;
                        std::cout << "Tracking Status::" << result.directionList[i].trackingStatus << std::endl;
                        std::cout << "Rect X::" << pLoc.x << std::endl;
                        std::cout << "Rect Y::" << pLoc.y << std::endl;
                        std::cout << "Direction Value::" << result.directionList[i].direction << std::endl;
                        std::cout << "Print Direction::" << direction_num2string(result.directionList[i].direction) << std::endl;
                        std::cout << "#######################trackTest##################" << std::endl;
                    }
                    else
                    {
                        cv::rectangle(pdInput.img, cv::Rect(pLoc.x,pLoc.y,pLoc.width,pLoc.height), cv::Scalar(0, 0, 255), 3, 8, 0);
                        if(result.directionList[i].direction == 4)
                        {
                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(200, 200, 200), 5, 5);
                        }
                        else
                        {
                            cv::putText(pdInput.img, direction_num2string(result.directionList[i].direction), cv::Point(pLoc.x-10, pLoc.y-10), cv::FONT_HERSHEY_SIMPLEX, 2.0, cv::Scalar(0, 0, 255), 5, 5);
                        }
                    }
                }
                std::cout << "per frame people count: " <<peopleCntPerImg<< std::endl;
            }
            time_2= boost::posix_time::microsec_clock::universal_time();
            frame_time = time_2 - time_start;
            fps = 1000.0/frame_time.total_milliseconds();
            cv::putText(pdInput.img, "fps:" + std::to_string(fps), cv::Point(pdInput.img.cols-400, 100), cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(200, 200, 200), 2, 2);
            IplImage* img = new IplImage(pdInput.img);
            cvShowImage("Janshe Video", img);
            if (cv::waitKey(1) == 'q')
            {
                break;
            }
        }
    }
    cvReleaseCapture( &capture );
    cvDestroyWindow( "Janshe Video" );
}


int TestcvSingleTracker(std::string videoPath)
{
    // declares all required variables
    Rect2d roi;
    Mat frame;
    // create a tracker object
    Ptr<Tracker> tracker = Tracker::create( "KCF" );
    // set input video
    VideoCapture cap(videoPath);
    // get bounding box
    cap >> frame;
    namedWindow("Tracker", WINDOW_KEEPRATIO);
    roi=selectROI("Tracker",frame);
    //quit if ROI was not selected
    if(roi.width==0 || roi.height==0)
        return 0;
    // initialize the tracker
    tracker->init(frame,roi);
    // perform the tracking process
    printf("Start the tracking process, press ESC to quit.\n");
    for ( ;; ){
        // get frame from the video
        cap >> frame;
        // stop the program if no more images
        if(frame.rows==0 || frame.cols==0)
            break;
        // update the tracking result
        tracker->update(frame,roi);
        // draw the tracked object
        rectangle( frame, roi, Scalar( 255, 0, 0 ), 2, 1 );
        // show image with the tracked object
        imshow("Tracker",frame);
        //quit on ESC button
        if(waitKey(1)==27)break;
    }
    return 0;
}

int TestMultiTracker(std::string videoPath)
{
    MultiTracker trackers("KCF");
    vector<Rect2d> objects;
    VideoCapture cap(videoPath);
    Mat frame;
    cap >> frame;
    namedWindow("tracker", WINDOW_KEEPRATIO);
    selectROI("tracker", frame, objects);

    //quit when the tracked object(s) is not provided
    if (objects.size() < 1) {
        return 0;
    }

    // initialize the tracker
    trackers.add(frame, objects);

    // do the tracking
    printf("Start the tracking process, press ESC to quit.\n");
    for (;;) {
        cap >> frame;

        // stop the program if no more images
        if (frame.rows == 0 || frame.cols == 0) {
            break;
        }

        //update the tracking result
        trackers.update(frame);

        // draw the tracked object
        for (unsigned i = 0; i < trackers.objects.size(); i++)
            rectangle(frame, trackers.objects[i], Scalar(255, 0, 0), 2, 1);

        // show image with the tracked object
        imshow("tracker", frame);

        //quit on ESC button
        if (waitKey(1) == 27)break;
    }

    return 0;
}


int main() {
//    /* Version test */
//    {
//        std::string version = getVersion();
//        std::cout << version << std::endl;
//    }

//    YoloFolderTest("/data/Pedestrian detection/data/empic");
    //trackTest("/data/Pedestrian detection/data/empic/list.txt");
//    trackTest("/data/Pedestrian detection/data/yttt/list.txt");
//    VideoTrackC("/home/yuankui/下载/192.168.6.26_01_2018082210125997.mp4");
    VideoTrack("../test_videos/20180827_184433.mp4");
//    TestcvSingleTracker("/data/Pedestrian detection/data/em-video/2018.8.7/192.168.100.93_01_20180807115613896_1.mp4");
//    TestMultiTracker("/data/Pedestrian detection/data/em-video/2018.8.7/192.168.100.93_01_20180807115613896_1.mp4");
    return 0;
}